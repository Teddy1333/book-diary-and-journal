package com.example.bookproject;

import static com.example.bookproject.R.id.list_view_books;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private ListView listViewBooks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewBooks = findViewById(list_view_books);
        databaseHelper = new DatabaseHelper(this);


        listViewBooks.setOnItemClickListener((parent, view, position, id) -> {
            Book selectedBook = (Book) parent.getItemAtPosition(position);
            Intent intent = new Intent(MainActivity.this, NotesActivity.class);
            intent.putExtra("bookId", selectedBook.getId());
            startActivity(intent);
        });

        loadBooks();

    }

    private void loadBooks() {
        List<Book> books = databaseHelper.getAllBooks();



        ArrayAdapter<Book> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, books) {
            @Override
            public View getView(int position, View convertView, android.view.ViewGroup parent) {
                View view = super.getView(position, convertView, parent);

                TextView textView = view.findViewById(android.R.id.text1);

                textView.setTextColor(getResources().getColor(R.color.purple)); // Set your custom color here
                return view;
            }
        };

        listViewBooks.setAdapter(adapter);


    }


    public void openAddBook(View view) {
        Intent intent = new Intent(this, AddBookActivity.class);
        startActivity(intent);
    }
    public void openAddNote(View view) {
        Intent intent = new Intent(this, NotesActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadBooks();
    }



}