package com.example.bookproject;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class NotesActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private ListView listViewNotes;
    private EditText editTextNote;
    private TextView textNoNotes;
    private int bookId;
    private String selectedNote = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        listViewNotes = findViewById(R.id.list_view_notes);
        editTextNote = findViewById(R.id.editTextNote);
        textNoNotes = findViewById(R.id.text_no_notes);

        databaseHelper = new DatabaseHelper(this);

        bookId = getIntent().getIntExtra("bookId", -1);

        loadNotes();

        listViewNotes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected note
                selectedNote = (String) listViewNotes.getItemAtPosition(position);
                editTextNote.setText(selectedNote); // Display it in the EditText
                Toast.makeText(NotesActivity.this, "Selected Note: " + selectedNote, Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.deleteNoteFromDatabase).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String noteToDelete = editTextNote.getText().toString().trim();

                if (noteToDelete.isEmpty()) {
                    Toast.makeText(NotesActivity.this, "Please enter the note to delete", Toast.LENGTH_SHORT).show();
                } else {
                    deleteNoteFromDatabase(noteToDelete);
                }
            }
        });

        findViewById(R.id.button_update_note).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String updatedNote = editTextNote.getText().toString().trim();

                if (updatedNote.isEmpty()) {
                    Toast.makeText(NotesActivity.this, "Please enter the updated note", Toast.LENGTH_SHORT).show();
                } else if (selectedNote == null) {
                    Toast.makeText(NotesActivity.this, "No note selected to update", Toast.LENGTH_SHORT).show();
                } else {
                    updateNoteInDatabase(selectedNote, updatedNote);
                }
            }
        });
    }

    private void loadNotes() {
        List<String> notesList = getNotesForBook(bookId);

        if (notesList.isEmpty()) {
            textNoNotes.setVisibility(View.VISIBLE);
            listViewNotes.setVisibility(View.GONE);  // Hide the ListView
        } else {
            textNoNotes.setVisibility(View.GONE);
            listViewNotes.setVisibility(View.VISIBLE);

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, notesList);
            listViewNotes.setAdapter(adapter);
        }
    }

    private List<String> getNotesForBook(int bookId) {
        List<String> notesList = new ArrayList<>();
        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        String query = "SELECT note FROM notes WHERE book_id = ?";
        String[] selectionArgs = {String.valueOf(bookId)};

        try (Cursor cursor = db.rawQuery(query, selectionArgs)) {
            while (cursor.moveToNext()) {
                notesList.add(cursor.getString(0));
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error loading notes: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            db.close();
        }

        return notesList;
    }

    public void saveNote(View view) {
        String noteText = editTextNote.getText().toString().trim();

        if (noteText.isEmpty()) {
            Toast.makeText(this, "Please enter a note", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("book_id", bookId);
        values.put("note", noteText);

        long result = db.insert("notes", null, values);
        db.close();

        if (result == -1) {
            Toast.makeText(this, "Failed to save note", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Note saved", Toast.LENGTH_SHORT).show();
            editTextNote.setText(""); // Clear input field
            loadNotes(); // Refresh notes list
        }
    }

    private void deleteNoteFromDatabase(String note) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        int rowsDeleted = db.delete("notes", "note = ? AND book_id = ?", new String[]{note, String.valueOf(bookId)});
        db.close();

        if (rowsDeleted > 0) {
            Toast.makeText(this, "Note deleted", Toast.LENGTH_SHORT).show();
            loadNotes(); // Refresh notes list after deletion
        } else {
            Toast.makeText(this, "Note not found", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateNoteInDatabase(String oldNote, String newNote) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("note", newNote);

        int rowsUpdated = db.update("notes", values, "note = ? AND book_id = ?", new String[]{oldNote, String.valueOf(bookId)});
        db.close();

        if (rowsUpdated > 0) {
            Toast.makeText(this, "Note updated successfully", Toast.LENGTH_SHORT).show();
            editTextNote.setText(""); // Clear input field
            selectedNote = null; // Clear selected note
            loadNotes(); // Refresh notes list
        } else {
            Toast.makeText(this, "Note update failed", Toast.LENGTH_SHORT).show();
        }
    }
}
