package com.example.bookproject;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddBookActivity extends AppCompatActivity {

    private EditText editTextTitle, editTextAuthor;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);

        editTextTitle = findViewById(R.id.edit_text_title);
        editTextAuthor = findViewById(R.id.edit_text_author);
        databaseHelper = new DatabaseHelper(this);
    }

    public void saveBook(View view) {
        String title = editTextTitle.getText().toString().trim();
        String author = editTextAuthor.getText().toString().trim();

        // Validation checks
        if (title.isEmpty() || author.isEmpty()) {
            Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (title.length() < 3 || title.length() > 100) {
            Toast.makeText(this, "Title must be between 3 and 100 characters", Toast.LENGTH_SHORT).show();
            return;
        }

        if (author.length() < 3 || author.length() > 50) {
            Toast.makeText(this, "Author name must be between 3 and 50 characters", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!title.matches("[a-zA-Z0-9 .,-]+")) {
            Toast.makeText(this, "Title contains invalid characters", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!author.matches("[a-zA-Z .,-]+")) {
            Toast.makeText(this, "Author name contains invalid characters", Toast.LENGTH_SHORT).show();
            return;
        }

        Book book = new Book(title, author);
        databaseHelper.addBook(book);
        Toast.makeText(this, "Book added", Toast.LENGTH_SHORT).show();
        finish();
    }
}
